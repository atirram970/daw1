package unidad6.edificio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Edificio {
    // Atributos
    private List<Persona> personasEnEdificio;
    private List<Persona> personasEnZonaPrivada;
    private Map<String, Persona> personasAutorizadas;

    // Constructor
    public Edificio() {
        personasEnEdificio = new ArrayList<>();
        personasEnZonaPrivada = new ArrayList<>();
        personasAutorizadas = new HashMap<>();
    }

    // Métodos
    /**
     * Método que comprueba que el DNI pasado por parámetro no sea nulo ni vacío.
     * Si no existe en la lista de edificio, se agrega y se registra la hora de entrada.
     * @param persona
     * @param horaEntrada
     */
    public void ingresarPersona(Persona persona, String horaEntrada) {
        if (persona != null && !persona.getDni().isEmpty()) {
            if (!existePersonaEnEdificio(persona.getDni())) {
                persona.setHoraEntrada(horaEntrada);
                personasEnEdificio.add(persona);
                System.out.println("Persona ingresada al edificio: " + persona);
            } else {
                System.out.println("La persona ya está en el edificio.");
            }
        } else {
            System.out.println("La persona proporcionada es nula o el DNI está vacío.");
        }
    }

    /**
     * Método que busca si el DNI de la persona se encontraba en la lista de edificio.
     * Si se encuentra, se elimina de la lista de edificio y se registra la hora de salida.
     * @param dni
     * @param horaSalida
     */
    public void quitarPersonaEnEdificio(String dni, String horaSalida) {
        Persona persona = buscarPersonaEnEdificio(dni);
        if (persona != null) {
            persona.setHoraSalida(horaSalida);
            personasEnEdificio.remove(persona);
            personasEnZonaPrivada.remove(persona);
            System.out.println("Persona salió del edificio: " + persona);
        } else {
            System.out.println("La persona no estaba en el edificio.");
        }
    }

    /**
     * Método que busca si el DNI de la persona se encontraba en la lista de zona privada.
     * Si se encuentra, se agrega a la zona privada y se registra la hora de entrada.
     * @param persona
     * @param horaEntradaPrivada
     */
    public void agregarPersonaEnZonaPrivada(Persona persona, String horaEntradaPrivada) {
        if (persona != null && !persona.getDni().isEmpty()) {
            if (!personasEnZonaPrivada.contains(persona)) {
                personasEnZonaPrivada.add(persona);
                personasAutorizadas.put(persona.getDni(), persona);
                System.out.println("Persona ingresada a la zona privada: " + persona);
            } else {
                System.out.println("La persona ya está en la zona privada.");
            }
        } else {
            System.out.println("La persona proporcionada es nula o el DNI está vacío.");
        }
    }

    /**
     * Método que busca si el DNI de la persona se encontraba en la lista de zona privada.
     * Si se encuentra, se elimina de la zona privada.
     * @param dni
     * @param horaSalidaPrivada
     */
    public void quitarPersonaEnZonaPrivada(String dni, String horaSalidaPrivada) {
        Persona persona = buscarPersonaEnZonaPrivada(dni);
        if (persona != null) {
            personasEnZonaPrivada.remove(persona);
            System.out.println("Persona abandonó la zona privada: " + persona);
        } else {
            System.out.println("La persona no estaba en la zona privada.");
        }
    }

    /**
     * Método que busca si el DNI de la persona se encontraba previamente en la lista del edificio.
     * @param dni
     */
    public Persona buscarPersonaEnEdificio(String dni) {
        for (Persona persona : personasEnEdificio) {
            if (persona.getDni().equals(dni)) {
                return persona;
            }
        }
        return null;
    }

    /**
     * Método que busca si el DNI de la persona se encontraba previamente en la lista de la zona privada.
     * @param dni
     */
    public Persona buscarPersonaEnZonaPrivada(String dni) {
        for (Persona persona : personasEnZonaPrivada) {
            if (persona.getDni().equals(dni)) {
                return persona;
            }
        }
        return null;
    }

    /**
     * Método que comprueba si el DNI de la persona que se le introduce por parámetro existe en la lista de edificio.
     * @param dni
     */
    public boolean existePersonaEnEdificio(String dni) {
        for (Persona persona : personasEnEdificio) {
            if (persona.getDni().equals(dni)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Método que permite agregar una persona a la lista de personas autorizadas a acceder a la zona privada.
     * @param persona
     */
    public void agregarPersonaAutorizada(Persona persona) {
        if (persona != null && !persona.getDni().isEmpty()) {
            personasAutorizadas.put(persona.getDni(), persona);
        } else {
            System.out.println("La persona proporcionada es nula o el DNI está vacío.");
        }
    }

    // Getters
    /**
     * Getter que obtiene las personas que se encuentran en el edificio.
     */
    public List<Persona> getPersonasEnEdificio() {
        return personasEnEdificio;
    }

    /**
     * Getter que obtiene las personas que se encuentran en la zona privada.
     */
    public List<Persona> getPersonasEnZonaPrivada() {
        return personasEnZonaPrivada;
    }
}