package recuperacionDesarrolloClases;

public interface Hipotecable {
	//métodos
	public double calcularCuota();
}
