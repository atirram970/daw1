package examen;

public class ej2 {

	public static void main(String[] args) {
		//Contador descendiente 4 impares seguidos de un par
		/*int contadorIMPAR=0;
		int contadorPAR=0;
		
		for (int contador = 100; contador >= 0 ; contador--) 
		{
			if (contador%2 == 0) 
			{
				contadorPAR = contadorPAR++;
			}
			else
			{
				contadorIMPAR = contadorIMPAR++;
			}
			
			if (contadorPAR == 1) 
			{
				System.out.println(contador);
				contadorPAR = 0;
			}
			for (contadorIMPAR < 5; contadorIMPAR++) 
			{
				System.out.println(contador);
			}
			
		}*/
		
		//no he conseguido terminar el ejercicio de manera satisfactoria
	}

}
