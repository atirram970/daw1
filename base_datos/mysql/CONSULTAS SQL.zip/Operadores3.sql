DROP DATABASE IF EXISTS Productos;
CREATE DATABASE Productos;
USE Productos;

CREATE TABLE PRODUCTOS (
	id_producto INT PRIMARY KEY AUTO_INCREMENT,
	nombre_producto VARCHAR (255),
	categoria VARCHAR (255),
	stock INT,
	precio_unitario FLOAT);
	
INSERT INTO PRODUCTOS (nombre_producto,categoria,stock,precio_unitario) 
VALUES ('Smartphone','Electronica', 25, 399.99),
('Camiseta','Ropa', 50, 19.99),
('Leche','Alimentos', 100, 1.50),
('Destronillador','Herramientas', 15, 9.99),
('Portatil','Electronica', 10, 899.99),
('Pantalones','Ropa', 30, 99.99),
('Manzanas','Alimentos', 75, 0.50),
('Martillo','Herramientas', 20, 12.99),
('Tablet','Electronica', 8, 299.99),
('Chaqueta','Ropa', 20, 49.99),
('Queso','Alimentos', 50, 2.99),
('Taladro','Herramientas', 12, 39.99),
('Altavoces','Electronica', 18, 149.99),
('Bufanda','Ropa', 40, 14.99),
('Arroz','Alimentos', 90, 1.20),
('Destapacañerias','Herramientas', 5, 7.99),
('Televisor','Electronica', 6, 699.99),
('Zapatos','Ropa', 35, 39.99),
('Pan','Alimentos', 120, 0.80),
('CintaMetrica','Herramientas', 10, 5.99),
('Auriculares','Electronica', 22, 79.99),
('Vestido','Ropa', 15, 59.99),
('Cerveza','Alimentos', 65, 1.99),
('LlaveInglesa','Herraminetas', 9, 8.99),
('Monitor','Electronica', 9, 119.99),
('Jersey','Ropa', 25, 34.99),
('Pasta','Alimentos', 80, 1.30),
('DestornilladorElectronico','Herramientas', 18, 24.99),
('Camara','Electronica', 7, 449.99),
('Gorra','Ropa', 50, 9.99);

-- Encuentra todos los productos que tienen el mismo precio unitario que otro producto.

SELECT id_producto, nombre_producto, precio_unitario
FROM PRODUCTOS
WHERE precio_unitario IN (SELECT precio_unitario FROM PRODUCTOS GROUP BY precio_unitario HAVING COUNT(*) > 1);

	-- Otra forma de hacerla

SELECT P.id_producto, P.nombre_producto, P.precio_unitario
FROM PRODUCTOS AS P
INNER JOIN (SELECT precio_unitario 
	    FROM PRODUCTOS 
	    GROUP BY precio_unitario 
	    HAVING COUNT(*) > 1) AS PR
	    ON P.precio_unitario = PR.precio_unitario;

-- Encuentra todos los productos que tienen el mismo nombre de categoría que otro producto.

SELECT id_producto, nombre_producto, precio_unitario
FROM PRODUCTOS
WHERE nombre_producto IN (SELECT precio_unitario FROM PRODUCTOS GROUP BY nombre_producto HAVING COUNT(*) > 1);

-- Encuentra todos los productos cuyo nombre es más largo que su categoría.


-- Encuentra todos los productos cuyo precio unitario es un número entero.
-- Encuentra el producto con el mayor valor total (stock * precio unitario).

