-- Seleccionar o crear la base de datos
CREATE DATABASE IF NOT EXISTS dragonBall;
USE dragonBall;

-- Crear la tabla Personajes
CREATE TABLE Personajes (
    id_personaje INT PRIMARY KEY,
    nombre VARCHAR(255),
    raza VARCHAR(255),
    nivel_poder INT
);

-- Insertar datos en la tabla Personajes
INSERT INTO Personajes (id_personaje, nombre, raza, nivel_poder) VALUES
(1, 'Goku', 'Saiyan', 9000),
(2, 'Vegeta', 'Saiyan', 8500),
(3, 'Piccolo', 'Namekiano', 5000);

-- Crear la tabla Tecnicas
CREATE TABLE Tecnicas (
    id_tecnica INT PRIMARY KEY,
    nombre VARCHAR(255),
    descripcion VARCHAR(255),
    id_personaje INT,
    FOREIGN KEY (id_personaje) REFERENCES Personajes(id_personaje)
);

-- Insertar datos en la tabla Tecnicas
INSERT INTO Tecnicas (id_tecnica, nombre, descripcion, id_personaje) VALUES
(1, 'Kamehameha', 'Poderosa técnica de energía', 1),
(2, 'Final Flash', 'Ataque explosivo de energía', 2),
(3, 'Makankosappo', 'Perforante rayo de energía', 3);

