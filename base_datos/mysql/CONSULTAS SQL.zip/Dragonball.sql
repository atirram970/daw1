CREATE DATABASE DragonBall;
USE DragonBall;

CREATE TABLE Planetas (
	id_planeta INT PRIMARY KEY,
	nombre VARCHAR (100),
	tipo VARCHAR (100),
	habitantes INT);

INSERT INTO Planetas (id_planeta, nombre, tipo, habitantes) VALUES (1, 'Namek', 'planeta', 1000);

INSERT INTO Planetas (id_planeta, nombre, tipo, habitantes) VALUES (2, 'Tierra', 'planeta', 300);

INSERT INTO Planetas (id_planeta, nombre, tipo, habitantes) VALUES (3, 'PlanetaSaiyan', 'planeta',4000);

CREATE TABLE Villanos (
	id_villano INT PRIMARY KEY,
	nombre VARCHAR (100),
	raza VARCHAR (100),
	planeta_origen VARCHAR (100),
	nivel_poder INT,
	descripcion VARCHAR (100) DEFAULT '');

INSERT INTO Villanos (id_villano,nombre,raza,planeta_origen,nivel_poder,descripcion) VALUES (1,'Freezer','lagartija','Namek',600,'Frigorifico');

INSERT INTO Villanos (id_villano,nombre,raza,planeta_origen,nivel_poder,descripcion) VALUES (2,'Cell','saltamontes','tierra',1000,'celula');

INSERT INTO Villanos (id_villano,nombre,raza,planeta_origen,nivel_poder,descripcion) VALUES (3,'MajinBuu','gelatina','tierra',2000,' ');


CREATE TABLE Razas (
	id_raza INT PRIMARY KEY,
	nombre VARCHAR (100),
	descripcion VARCHAR (100) DEFAULT '');

INSERT INTO Razas (id_raza, nombre, descripcion) VALUES (1, 'Saiyan', 'vegetariano');

INSERT INTO Razas (id_raza, nombre, descripcion) VALUES (2, 'Namekiano', ' ');

INSERT INTO Razas (id_raza, nombre, descripcion) VALUES (3, 'Androide', 'Humanoides');







