DROP DATABASE IF EXISTS CaballerosDelZodiaco;
CREATE DATABASE CaballerosDelZodiaco;
USE CaballerosDelZodiaco


CREATE TABLE Constelaciones (
	id_Constelacion INT PRIMARY KEY AUTO_INCREMENT,
	Nombre VARCHAR (255),
	Descripcion VARCHAR (255));
	
INSERT INTO Constelaciones (Nombre,Descripcion) VALUES ('Acuario','Acuario constelacion');
INSERT INTO Constelaciones (Nombre,Descripcion) VALUES ('Aries','Aries constelacion');
INSERT INTO Constelaciones (Nombre,Descripcion) VALUES ('Capricornio','Capri constelacion');

CREATE TABLE Caballeros (
	id_Caballeros INT PRIMARY KEY AUTO_INCREMENT,
	Nombre VARCHAR(255),
	SignoZodiacal VARCHAR (255) UNIQUE,
	ConstelacionID INT REFERENCES Constelaciones(id_Constelacion));

INSERT INTO Caballeros (Nombre,SignoZodiacal, ConstelacionID) VALUES ('Mu','aries','1');
INSERT INTO Caballeros (Nombre,SignoZodiacal, ConstelacionID) VALUES ('Milo','escorpio', '2');
INSERT INTO Caballeros (Nombre,SignoZodiacal, ConstelacionID) VALUES ('Aldebaran','acuario', '3');

SELECT * FROM Constelaciones;

SELECT * FROM Caballeros;

