DROP DATABASE IF EXISTS empleados;
CREATE DATABASE empleados CHARACTER SET utf8mb4;
USE empleados;

CREATE TABLE departamento (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  presupuesto DOUBLE UNSIGNED NOT NULL,
  gastos DOUBLE UNSIGNED NOT NULL
);

CREATE TABLE empleado (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nif VARCHAR(9) NOT NULL UNIQUE,
  nombre VARCHAR(100) NOT NULL,
  apellido1 VARCHAR(100) NOT NULL,
  apellido2 VARCHAR(100),
  id_departamento INT UNSIGNED,
  FOREIGN KEY (id_departamento) REFERENCES departamento(id)
);

INSERT INTO departamento VALUES
(1, 'Desarrollo', 120000, 6000),
(2, 'Sistemas', 150000, 21000),
(3, 'Recursos Humanos', 280000, 25000),
(4, 'Contabilidad', 110000, 3000),
(5, 'I+D', 375000, 380000),
(6, 'Proyectos', 0, 0),
(7, 'Publicidad', 0, 1000);

INSERT INTO empleado VALUES
(1, '32481596F', 'Aarón', 'Rivero', 'Gómez', 1),
(2, 'Y5575632D', 'Adela', 'Salas', 'Díaz', 2),
(3, 'R6970642B', 'Adolfo', 'Rubio', 'Flores', 3),
(4, '77705545E', 'Adrián', 'Suárez', NULL, 4),
(5, '17087203C', 'Marcos', 'Loyola', 'Méndez', 5),
(6, '38382980M', 'María', 'Santana', 'Moreno', 1),
(7, '80576669X', 'Pilar', 'Ruiz', NULL, 2),
(8, '71651431Z', 'Pepe', 'Ruiz', 'Santana', 3),
(9, '56399183D', 'Juan', 'Gómez', 'López', 2),
(10, '46384486H', 'Diego','Flores', 'Salas', 5),
(11, '67389283A', 'Marta','Herrera', 'Gil', 1),
(12, '41234836R', 'Irene','Salas', 'Flores', NULL),
(13, '82635162B', 'Juan Antonio','Sáez', 'Guerrero', NULL);

SHOW TABLES;
SELECT * FROM departamento;
SELECT * FROM empleado;

-- 1.- Calcula la suma del presupuesto de todos los departamentos.

SELECT SUM(presupuesto) AS PresupuestoTotal
FROM departamento;

-- 2.- Calcula la media del presupuesto de todos los departamentos.

SELECT ROUND(AVG(presupuesto),2) AS PresupuestoMedio
FROM departamento;

-- 3.- Calcula el valor mínimo del presupuesto de todos los departamentos.

SELECT MIN(presupuesto) AS PresupuestoMinimo
FROM departamento;

-- 4.- Calcula el nombre del departamento y el presupuesto que tiene asignado, del departamento con menor presupuesto.

SELECT nombre, MIN(presupuesto) AS PresupuestoMinimo
FROM departamento
GROUP BY nombre
ORDER BY PresupuestoMinimo LIMIT 1;

-- 5.- Calcula el valor máximo del presupuesto de todos los departamentos.

SELECT MAX(presupuesto) AS PresupuestoMaximo
FROM departamento;

-- 6.- Calcula el nombre del departamento y el presupuesto que tiene asignado, del departamento con mayor presupuesto.

SELECT nombre, MAX(presupuesto) AS PresupuestoMaximo
FROM departamento
GROUP BY nombre
ORDER BY PresupuestoMaximo DESC LIMIT 1;

-- 7.-  Calcula el número total de empleados que hay en la tabla empleado.

SELECT COUNT(id) AS NumEmpleados
FROM empleado;

-- 8.- Calcula el número de empleados que no tienen NULL en su segundo apellido.

SELECT COUNT(id) AS NumEmpleados
FROM empleado
WHERE apellido2 IS NOT NULL;

-- 9.- Calcula el número de empleados que hay en cada departamento. Tienes que devolver dos columnas, una con el nombre del departamento y otra con el número de empleados que tiene asignados.

SELECT departamento.nombre, COUNT(empleado.id_departamento) AS NumEmpleadosDepartamento
FROM empleado
INNER JOIN departamento
ON empleado.id_departamento = departamento.id
GROUP BY departamento.nombre;

-- 10.- Calcula el nombre de los departamentos que tienen más de 2 empleados. El resultado debe tener dos columnas, una con el nombre del departamento y otra con el número de empleados que tiene asignados.

SELECT departamento.nombre, COUNT(id_departamento) AS NumEmpleadosDepartamento
FROM empleado
INNER JOIN departamento
ON empleado.id_departamento = departamento.id
GROUP BY departamento.nombre
HAVING NumEmpleadosDepartamento > 2;

-- 11.- Calcula el número de empleados que trabajan en cada uno de los departamentos. El resultado de esta consulta también tiene que incluir aquellos departamentos que no tienen ningún empleado asociado.

SELECT departamento.nombre, 
(SELECT COUNT(id_departamento) FROM empleado WHERE empleado.id_departamento = departamento.id) AS numero_empleado 
FROM departamento;

-- 12.- Calcula el número de empleados que trabajan en cada unos de los departamentos que tienen un presupuesto mayor a 200000 euros.

SELECT departamento.presupuesto, departamento.nombre, COUNT(id_departamento) AS NumEmpleadosDepartamento
FROM empleado
INNER JOIN departamento
ON empleado.id_departamento = departamento.id
WHERE departamento.presupuesto > 200000
GROUP BY departamento.nombre, departamento.presupuesto;

