DROP DATABASE IF EXISTS EMPRESA;
CREATE DATABASE EMPRESA;
USE EMPRESA;



CREATE TABLE departamento (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(255)
);

CREATE TABLE empleado (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(255),
    id_departamento INT,
    FOREIGN KEY (id_departamento) REFERENCES departamento(id)
);

INSERT INTO departamento (nombre) VALUES ('Desarrollo');
INSERT INTO departamento (nombre) VALUES ('Sistemas');
INSERT INTO departamento (nombre) VALUES ('Recursos Humanos');
INSERT INTO empleado (nombre, id_departamento) VALUES ('Pepe', 1);
INSERT INTO empleado (nombre, id_departamento) VALUES ('Maria', 1);
INSERT INTO empleado (nombre, id_departamento) VALUES ('Juan', NULL);
	

	


