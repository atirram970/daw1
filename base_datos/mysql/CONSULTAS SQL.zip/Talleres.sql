DROP IF EXISTS DBZ_Ejercicio_Calculos;
CREATE DATABASE DBZ_Ejercicio_Calculos;
USE DBZ_Ejercicio_Calculos;

CREATE TABLE Guerreros (
	id INT AUTO_INCREMENT PRIMARY KEY,
	nombre VARCHAR (255),
	raza VARCHAR (255),
	cantidad_transformaciones INT);
