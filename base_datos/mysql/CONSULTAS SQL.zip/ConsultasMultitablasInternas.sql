DROP DATABASE IF EXISTS empleados;
CREATE DATABASE empleados CHARACTER SET utf8mb4;
USE empleados;

CREATE TABLE departamento (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  presupuesto DOUBLE UNSIGNED NOT NULL,
  gastos DOUBLE UNSIGNED NOT NULL
);

CREATE TABLE empleado (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nif VARCHAR(9) NOT NULL UNIQUE,
  nombre VARCHAR(100) NOT NULL,
  apellido1 VARCHAR(100) NOT NULL,
  apellido2 VARCHAR(100),
  id_departamento INT UNSIGNED,
  FOREIGN KEY (id_departamento) REFERENCES departamento(id)
);

INSERT INTO departamento VALUES
(1, 'Desarrollo', 120000, 6000),
(2, 'Sistemas', 150000, 21000),
(3, 'Recursos Humanos', 280000, 25000),
(4, 'Contabilidad', 110000, 3000),
(5, 'I+D', 375000, 380000),
(6, 'Proyectos', 0, 0),
(7, 'Publicidad', 0, 1000);

INSERT INTO empleado VALUES
(1, '32481596F', 'Aarón', 'Rivero', 'Gómez', 1),
(2, 'Y5575632D', 'Adela', 'Salas', 'Díaz', 2),
(3, 'R6970642B', 'Adolfo', 'Rubio', 'Flores', 3),
(4, '77705545E', 'Adrián', 'Suárez', NULL, 4),
(5, '17087203C', 'Marcos', 'Loyola', 'Méndez', 5),
(6, '38382980M', 'María', 'Santana', 'Moreno', 1),
(7, '80576669X', 'Pilar', 'Ruiz', NULL, 2),
(8, '71651431Z', 'Pepe', 'Ruiz', 'Santana', 3),
(9, '56399183D', 'Juan', 'Gómez', 'López', 2),
(10, '46384486H', 'Diego','Flores', 'Salas', 5),
(11, '67389283A', 'Marta','Herrera', 'Gil', 1),
(12, '41234836R', 'Irene','Salas', 'Flores', NULL),
(13, '82635162B', 'Juan Antonio','Sáez', 'Guerrero', NULL);

SHOW TABLES;
SELECT * FROM departamento;
SELECT * FROM empleado;

-- 1.- Devuelve un listado con los empleados y los datos de los departamentos donde trabaja cada uno.

SELECT *
FROM empleado, departamento
WHERE empleado.id_departamento = departamento.id;


-- 2.- Devuelve un listado con los empleados y los datos de los departamentos donde trabaja cada uno. Ordena el resultado, en primer lugar por el nombre del departamento (en orden alfabético) y en segundo lugar por los apellidos y el nombre de los empleados.

SELECT *
FROM empleado, departamento
WHERE empleado.id_departamento = departamento.id
ORDER BY departamento.nombre ASC, empleado.apellido1, empleado.apellido2, empleado.nombre;

-- 3.- Devuelve un listado con el identificador y el nombre del departamento, solamente de aquellos departamentos que tienen empleados.

SELECT departamento.id, departamento.nombre
FROM departamento, empleado
WHERE departamento.id = empleado.id_departamento
GROUP BY departamento.id, departamento.nombre;

-- 4.- Devuelve un listado con el identificador, el nombre del departamento y el valor del presupuesto actual del que dispone, solamente de aquellos departamentos que tienen empleados. El valor del presupuesto actual lo puede calcular restando al valor del presupuesto inicial (columna presupuesto) el valor de los gastos que ha generado (columna gastos).

SELECT departamento.id, departamento.nombre, (departamento.presupuesto - departamento.gastos) AS PresupuestoActual
FROM departamento, empleado
WHERE departamento.id = empleado.id_departamento
GROUP BY departamento.id, departamento.nombre, PresupuestoActual;

-- 5.- Devuelve el nombre del departamento donde trabaja el empleado que tiene el nif 38382980M.

SELECT departamento.nombre
FROM departamento, empleado
WHERE departamento.id = empleado.id_departamento AND empleado.nif = '38382980M';

-- 6.- Devuelve el nombre del departamento donde trabaja el empleado Pepe Ruiz Santana.

SELECT departamento.nombre
FROM departamento, empleado
WHERE departamento.id = empleado.id_departamento AND empleado.nombre = 'Pepe' AND empleado.apellido1 = 'Ruiz' AND empleado.apellido2 = 'Santana';

-- 7.- Devuelve un listado con los datos de los empleados que trabajan en el departamento de I+D. Ordena el resultado alfabéticamente.

SELECT *
FROM departamento, empleado
WHERE departamento.id = empleado.id_departamento AND departamento.nombre = 'I+D';

-- 8.- Devuelve un listado con los datos de los empleados que trabajan en el departamento de Sistemas, Contabilidad o I+D. Ordena el resultado alfabéticamente.

SELECT * 
FROM departamento, empleado
WHERE departamento.id = empleado.id_departamento
AND (departamento.nombre = 'I+D' OR departamento.nombre = 'Sistemas' OR departamento.nombre = 'Contabilidad');

-- 9.- Devuelve una lista con el nombre de los empleados que tienen los departamentos que no tienen un presupuesto entre 100000 y 200000 euros.

SELECT empleado.nombre
FROM empleado, departamento
WHERE empleado.id_departamento = departamento.id AND departamento.presupuesto NOT BETWEEN 100000 AND 200000;

-- 10.- Devuelve un listado con el nombre de los departamentos donde existe algún empleado cuyo segundo apellido sea NULL. Tenga en cuenta que no debe mostrar nombres de departamentos que estén repetidos.

SELECT DISTINCT departamento.nombre
FROM empleado, departamento
WHERE empleado.id_departamento = departamento.id AND apellido2 IS NULL;


