DROP DATABASE IF EXISTS Productos;
CREATE DATABASE Productos;
USE Productos;

CREATE TABLE PRODUCTOS (
	id_producto INT PRIMARY KEY AUTO_INCREMENT,
	nombre_producto VARCHAR (255),
	categoria VARCHAR (255),
	stock INT,
	precio_unitario DECIMAL);
	
INSERT INTO PRODUCTOS (nombre_producto,categoria,stock,precio_unitario) 
VALUES ('Smartphone','Electronica', 25, 399.99),
('Camiseta','Ropa', 50, 19.99),
('Leche','Alimentos', 100, 1.50),
('Destronillador','Herramientas', 15, 9.99),
('Portatil','Electronica', 10, 899.99),
('Pantalones','Ropa', 30, 99.99),
('Manzanas','Alimentos', 75, 0.50),
('Martillo','Herramientas', 20, 12.99),
('Tablet','Electronica', 8, 299.99),
('Chaqueta','Ropa', 20, 49.99),
('Queso','Alimentos', 50, 2.99),
('Taladro','Herramientas', 12, 39.99),
('Altavoces','Electronica', 18, 149.99),
('Bufanda','Ropa', 40, 14.99),
('Arroz','Alimentos', 90, 1.20),
('Destapacañerias','Herramientas', 5, 7.99),
('Televisor','Electronica', 6, 699.99),
('Zapatos','Ropa', 35, 39.99),
('Pan','Alimentos', 120, 0.80),
('CintaMetrica','Herramientas', 10, 5.99),
('Auriculares','Electronica', 22, 79.99),
('Vestido','Ropa', 15, 59.99),
('Cerveza','Alimentos', 65, 1.99),
('LlaveInglesa','Herraminetas', 9, 8.99),
('Monitor','Electronica', 9, 119.99),
('Jersey','Ropa', 25, 34.99),
('Pasta','Alimentos', 80, 1.30),
('DestornilladorElectronico','Herramientas', 18, 24.99),
('Camara','Electronica', 7, 449.99),
('Gorra','Ropa', 50, 9.99);

-- 1.-

SELECT nombre_producto, stock
FROM PRODUCTOS
WHERE stock < 10;

-- 2.-

SELECT nombre_producto, categoria
FROM PRODUCTOS
WHERE categoria IN ('Electronica', 'Ropa');

-- 3.-

SELECT nombre_producto, precio_unitario
FROM PRODUCTOS
WHERE precio_unitario > 100;

-- 4.-

SELECT nombre_producto, precio_unitario
FROM PRODUCTOS
ORDER BY precio_unitario DESC LIMIT 1;

-- 5.-

SELECT nombre_producto, categoria
FROM PRODUCTOS
ORDER BY stock DESC LIMIT 1;

-- 6.-

-- 6.-SELECT nombre_producto, precio_unitario
-- 6.-FROM PRODUCTOS
-- 6.-COUNT(30) SUM(precio_unitario) * 30;

-- 7.-

SELECT nombre_producto
FROM PRODUCTOS
WHERE nombre_producto LIKE 'A%' AND stock > 0;

-- 8.-

SELECT nombre_producto, categoria, precio_unitario
FROM PRODUCTOS
WHERE categoria NOT IN ('Alimentos') AND precio_unitario < 50;

--9.-

SELECT nombre_producto, stock
FROM PRODUCTOS
WHERE
