DROP DATABASE IF EXISTS ConsultaMultitabla;
CREATE DATABASE ConsultaMultitabla;
USE ConsultaMultitabla;

-- Tabla guerreros
CREATE TABLE guerreros (
    id_guerrero INT PRIMARY KEY,
    nombre VARCHAR(50),
    raza VARCHAR(50),
    nivel_poder INT
);

-- Insertar datos en la tabla guerreros
INSERT INTO guerreros (id_guerrero, nombre, raza, nivel_poder) VALUES
(1, 'Goku', 'Saiyan', 9000),
(2, 'Vegeta', 'Saiyan', 8500),
(3, 'Piccolo', 'Namekian', 5000),
(4, 'Gohan', 'Saiyan', 6000),
(5, 'Krilin', 'Humano', 4000);

-- Tabla técnicas
CREATE TABLE tecnicas (
    id_tecnica INT PRIMARY KEY,
    id_guerrero INT,
    nombre_tecnica VARCHAR(50),
    FOREIGN KEY (id_guerrero) REFERENCES guerreros(id_guerrero)
);

-- Insertar datos en la tabla técnicas
INSERT INTO tecnicas (id_tecnica, id_guerrero, nombre_tecnica) VALUES
(1, 1, 'Kamehameha'),
(2, 1, 'Genki Dama'),
(3, 2, 'Final Flash'),
(4, 3, 'Makankosappo'),
(5, 4, 'Masenko'),
(6, 5, 'Kienzan');

SELECT * FROM guerreros;
SELECT * FROM tecnicas;
