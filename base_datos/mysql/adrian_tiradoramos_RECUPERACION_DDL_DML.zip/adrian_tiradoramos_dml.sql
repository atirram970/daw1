use universia;

-- ej1
SELECT COUNT(id) AS `Número Profesoras` FROM persona
WHERE tipo LIKE 'profesor' AND sexo LIKE 'M';

-- ej2
SELECT COUNT(id) AS AlumnosEn2000 FROM persona
WHERE fecha_nacimiento LIKE '2000%';

-- ej3
SELECT g.nombre AS NomGrado, a.tipo AS TipoAsignatura, SUM(a.creditos) AS TotalCreditos FROM grado g 
LEFT JOIN asignatura a ON g.id = a.id_grado 
GROUP BY NomGrado, TipoAsignatura
ORDER BY TotalCreditos DESC;

-- ej4
SELECT g.nombre AS NomGrado, MIN(a.nombre) AS NomAsignatura, MAX(a.creditos) AS CreditoMaximo FROM grado g 
LEFT JOIN asignatura a ON g.id = a.id_grado 
GROUP BY NomGrado 
ORDER BY CreditoMaximo DESC;
