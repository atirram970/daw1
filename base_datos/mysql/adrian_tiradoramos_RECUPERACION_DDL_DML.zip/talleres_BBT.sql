DROP DATABASE IF EXISTS talleres_BBT;
CREATE DATABASE talleres_BBT;
use talleres_BBT;

CREATE TABLE Coches (
	matricula VARCHAR(8) PRIMARY KEY,
	marca VARCHAR(80),
	año_fabricacion INT,
	modelo VARCHAR(80)
);

CREATE TABLE Mecanicos (
	dni VARCHAR(9) PRIMARY KEY,
	nombre VARCHAR(80),
	puesto VARCHAR(80),
	salario DECIMAL(10, 2)
);

CREATE TABLE Clientes (
	id_cliente INT PRIMARY KEY,
	nombre VARCHAR(80),
	apellidos VARCHAR(80),
	telefono VARCHAR(9),
	mail VARCHAR(80)
);

CREATE TABLE Cliente_Coche (
	id_relacion INT PRIMARY KEY,
	id_cliente INT,
	matricula VARCHAR(8),
	FOREIGN KEY (id_cliente) REFERENCES Clientes(id_cliente),
	FOREIGN KEY (matricula) REFERENCES Coches(matricula)
);
