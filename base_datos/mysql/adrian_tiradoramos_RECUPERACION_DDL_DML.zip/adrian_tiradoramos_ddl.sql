use talleres_BBT;

-- ej2.1
ALTER TABLE Mecanicos CHANGE COLUMN salario `Bruto Anual` decimal(10, 2);

-- ej2.2
UPDATE Mecanicos SET `Bruto Anual` = `Bruto Anual` * 14;

-- ej3
UPDATE Clientes SET mail = CONCAT(UPPER(nombre), '..', mail);

-- ej4
DELETE FROM Cliente_Coche WHERE id_cliente = '11';
DELETE FROM Coches WHERE marca = 'Kia' AND modelo = 'Río';
DELETE FROM Clientes WHERE id_cliente = '11';
