package recuperacionArray;

public class utilidades {

	public static void main(String[] args) {
		int[][] arrayImagen = main.generarImagen(5, 5);
		main.contraste(arrayImagen, 25);
	}

}
