package unidad5.cuentasBancarias;

public class DatosIncorrectosPersonaException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7227567072998985072L;

	public DatosIncorrectosPersonaException(String message) {
		super(message);
	}
}
