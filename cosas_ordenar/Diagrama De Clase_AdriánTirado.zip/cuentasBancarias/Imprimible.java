package unidad5.cuentasBancarias;

public interface Imprimible {
	/**
	 * Este método permite devolver la información de las personas y de las cuentas bancarias
	 * @return
	 */
	public String devolverInfoString();
}
