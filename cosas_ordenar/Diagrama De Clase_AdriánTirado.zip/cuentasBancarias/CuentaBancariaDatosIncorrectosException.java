package unidad5.cuentasBancarias;

public class CuentaBancariaDatosIncorrectosException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4502683347007825322L;

	public CuentaBancariaDatosIncorrectosException(String message) {
		super(message);
	}

}
