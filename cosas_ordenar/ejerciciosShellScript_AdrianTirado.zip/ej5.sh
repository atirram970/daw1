#!/bin/bash
clear
echo "Hola mundo"
