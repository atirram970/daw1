#!/bin/bash
nParametros=$#
listaParametros=$*
primerParametro=$1
segundoParametro=$2
directorioHome=$HOME
directorioActual=$PWD

echo "Nº parametros: $nParametros"
echo "Lista parametros: $listaParametros"
echo "1º parametro: $primerParametro"
echo "2º parametro $segundoParametro"
echo "Directorio Home Del usuario: $directorioHome"
echo "Directorio actual: $directorioHome"
