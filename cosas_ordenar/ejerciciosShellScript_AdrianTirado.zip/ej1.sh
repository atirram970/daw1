#!/bin/bash
x=15

echo $x
