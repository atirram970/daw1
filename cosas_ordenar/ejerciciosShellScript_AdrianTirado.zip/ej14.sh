#!/bin/bash

for (( i = 1; i < 6; i++ )); do
  for (( j = 1; j <= i; j++ )); do
    echo -e "$j\c"
  done
  echo ""
done
