#!/bin/bash
a=20
b=5

echo $(($a/$b))
